/*
    morion.h
*/

#ifndef _MORION_H_
#define _MORION_H_

void ImprimirCarpeta();
void MyEcho(const char *msj);
void MyEcho(const char *msj);
void MyClr();
int MiCp(const char *from, const char *to);
void MyTime();
void LeerTexto(char* cadena, char* ruta);
void kill_p(int s, int ipid);

#endif